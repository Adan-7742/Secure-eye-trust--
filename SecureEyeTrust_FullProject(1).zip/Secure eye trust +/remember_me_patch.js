/* =========================================================================
   remember_me_patch.js — Secure Eye Trust+ Desktop Edition
   =========================================================================
   How to apply
   ────────────
   In  api/auth_api.py, find the `_EMBEDDED_LOGIN_HTML = """...."""` string
   constant. Just before its closing `</script></body></html>` add the
   following block (copy from BEGIN ↓ to ↑ END, paste inside the existing
   <script> tag at the very bottom of the embedded HTML):
*/

/* ─── BEGIN: paste from here ────────────────────────────────────────── */
(function rememberMePatch() {
  // Wrap the existing doLogin() so that, on success, we POST the creds
  // to /api/auth/remember-me. The desktop launcher will read them on
  // next start-up via Windows Credential Manager (DPAPI-encrypted).
  if (typeof window.doLogin !== 'function') return;
  var _origLogin = window.doLogin;
  window.doLogin = async function patchedLogin() {
    // Read the values *before* the original handler clears them
    var em = (document.getElementById('li-email') || {}).value || '';
    var pw = (document.getElementById('li-pw')    || {}).value || '';
    em = em.trim().toLowerCase();

    // Call the original sign-in (it handles UI feedback + redirect on success)
    var origResult = await _origLogin.apply(this, arguments);

    // After the original handler runs, try to detect a successful login.
    // The original handler triggers a navigation to '/' — we beat the
    // navigation by issuing a sync fetch.
    try {
      var probe = await fetch('/api/auth/firebase-status', {credentials:'include'});
      // We can't easily read session here, so just *attempt* to save —
      // the server only persists when the session email matches.
      if (em && pw) {
        navigator.sendBeacon
          ? navigator.sendBeacon('/api/auth/remember-me',
              new Blob([JSON.stringify({email:em, password:pw})],
                       {type:'application/json'}))
          : fetch('/api/auth/remember-me', {
              method:'POST',
              credentials:'include',
              headers:{'Content-Type':'application/json'},
              body: JSON.stringify({email:em, password:pw}),
              keepalive: true,
            });
      }
    } catch (e) { /* silent — saving creds is best-effort */ }

    return origResult;
  };
})();
/* ─── END: paste up to here ─────────────────────────────────────────── */

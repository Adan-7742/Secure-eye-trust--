@echo off
title Secure Eye Trust+ Build (Plain)
cd /d "%~dp0"

echo.
echo  ============================================================
echo    Secure Eye Trust+  -  PLAIN build (no obfuscation)
echo  ============================================================
echo    Folder: %CD%
echo  ============================================================
echo.
echo  This window will stay open until you close it manually.
echo.

if not exist build_protected.py (
    echo  [ERROR] build_protected.py is not in this folder.
    echo          Drop it next to app.py and try again.
    goto :END
)

if not exist app.py (
    echo  [ERROR] app.py is not in this folder.
    echo          Run this .bat from your project root.
    goto :END
)

echo  [INFO] Checking Python ...
python --version
if errorlevel 1 (
    echo.
    echo  [ERROR] Python is not on your PATH.
    echo          Install Python 3.11 from https://python.org
    goto :END
)

echo.
echo  [INFO] Running plain (unprotected) build via Python orchestrator ...
echo  ------------------------------------------------------------
echo.

set SET_BUILD_MODE=plain
python build_protected.py
set SET_BUILD_MODE=

echo.
echo  ------------------------------------------------------------
echo  [INFO] Python orchestrator finished with exit code %errorlevel%
echo.

:END
echo.
echo  ============================================================
echo   The window will remain open. Press any key to close it.
echo  ============================================================
pause >nul

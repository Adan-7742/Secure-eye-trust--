# Secure Eye Trust+ — Desktop `.exe` Build Guide

This package turns your Flask web app into a single Windows executable
that:

* Runs **inside a fixed-size native desktop window** (no browser tabs)
* **Bundles every Python package** — no install needed on the target PC
* **Asks for admin once via UAC** on first launch; saves an auto-start
  task that skips UAC on subsequent boots
* **Saves user login credentials** in the Windows Credential Manager
  (DPAPI-encrypted per user) so the login screen never re-appears
* **Keeps running in the background** via a system-tray icon even after
  the dashboard window is closed — analysis threads never stop
* **Protects your source code** — the `.exe` ships PyArmor-encrypted
  bytecode that can't be recovered with `pyinstxtractor` + `uncompyle`

---

## 0. What you'll get

```
your-project-root/
├── app.py                          (unchanged)
├── desktop_app.py                  ← NEW   main launcher
├── firebase_auth.py                (unchanged)
├── api/
│   ├── auth_api.py                 (one tiny JS paste — see step 3)
│   └── auth_desktop_api.py         ← NEW   auto-login + remember-me
├── utils/
│   └── credentials.py              ← NEW   Windows Credential Manager wrapper
├── templates/   static/   core/  …  (unchanged)
├── app.manifest                    ← NEW   UAC admin manifest
├── Secure_Eye_Trust.spec           ← NEW   PyInstaller config
├── requirements_build.txt          ← NEW   extended deps
├── build.bat                       ← NEW   plain build
├── build_protected.bat             ← NEW   obfuscated build
├── install_autostart.py            ← NEW   register Windows Scheduled Task
├── remember_me_patch.js            ← NEW   tiny patch for login HTML
└── BUILD_INSTRUCTIONS.md           ← NEW   this file
```

Final output → `dist/Secure_Eye_Trust.exe` (one file, ~250–400 MB).

---

## 1. One-time setup on the BUILD machine

You only need to do this on the machine that **builds** the `.exe`,
not on the target PCs.

1. **Windows 10/11 (64-bit)** with **Python 3.11 (64-bit)** on `PATH`.
2. (Optional but recommended) install **UPX** so the `.exe` shrinks by ~40%:
   download `upx-*-win64.zip` from <https://upx.github.io/>, unzip and
   add the folder to `PATH`.
3. Drop every file from this package into your project root next to
   `app.py`. Do **not** overwrite anything except where step 3 below
   says so.

---

## 2. Place an icon (optional but recommended)

Save a 256×256 PNG named `app_icon.png` **and** the same image converted
to `app_icon.ico` next to `app.py`. Free converter: <https://icoconvert.com/>.

The `.spec` file auto-detects them; if missing, the build still works
with a generic icon.

---

## 3. The ONE small edit to your existing code

Open `api/auth_api.py`. Find the constant `_EMBEDDED_LOGIN_HTML = """..."""`
(around line 15). Scroll inside that string to the very bottom — there's a
single `<script>` block. Paste the contents of `remember_me_patch.js`
(everything between `BEGIN` and `END`) inside that `<script>` block,
right before its closing `</script>`.

That's the only line of your existing source code you need to touch.

---

## 4. Provide Firebase credentials

Make sure a `.env` file exists in the project root with at minimum:

```
FIREBASE_API_KEY=AIza...
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_DATABASE_URL=https://your-project.firebaseio.com
GROQ_API_KEY=gsk_...
APP_USERNAME=admin
APP_PASSWORD=change_me_strong_password
SECRET_KEY=any-long-random-string
```

The `.env` ships *inside* the `.exe` (it's listed under `datas` in the
spec). If you want users to supply their own `.env`, remove that line
from `Secure_Eye_Trust.spec` and document where they should drop it
(`%LOCALAPPDATA%\SecureEyeTrust\.env`).

---

## 5. Build

### Plain build (faster — no source protection)
```bat
build.bat
```

### Protected build (recommended for distribution)
```bat
build_protected.bat
```

Either takes 5–15 minutes the first time (pip downloads, PyInstaller
analysis). Output appears in `dist\Secure_Eye_Trust.exe`.

---

## 6. Test on the build machine

```bat
cd dist
Secure_Eye_Trust.exe
```

What you should see:

1. **UAC prompt** — click *Yes* (required for Security/Firewall logs)
2. A **blank window** while Flask boots (5–10 s)
3. Either the **login screen** *or* (if you've used the app before) the
   **dashboard** loads directly via the auto-login token
4. After you sign in once, the credentials are saved. Close & reopen
   `Secure_Eye_Trust.exe` — you should land straight on the dashboard
5. Close the dashboard window — a **shield icon appears in the system
   tray**. Right-click it → *Open Dashboard* re-opens the window;
   *Quit* exits the process entirely.

---

## 7. Skip UAC on every launch (optional)

Run **once** as admin:

```bat
cd dist
python ..\install_autostart.py
```

This registers a Scheduled Task `SecureEyeTrustPlus_AutoStart` that:

* Launches the EXE at every user logon
* Runs with highest privileges (no UAC popup)
* Is invisible to non-admin users

Remove with `python ..\install_autostart.py --remove`.

---

## 8. Deploy to other PCs

Just copy `Secure_Eye_Trust.exe` to the target machine. Nothing else
is required — no Python install, no `pip install`. On first launch
the user data directory is created at:

```
%LOCALAPPDATA%\SecureEyeTrust\
    ├── database\
    │     ├── logs.db        ← created fresh
    │     ├── uploads.db     ← created fresh
    │     └── locker.db      ← created fresh
    ├── keys\
    └── session.json         ← pointer to Credential Manager entry
```

Each user gets their own encrypted credential store — User B cannot
read User A's saved password even on the same PC.

---

## 9. Customising the window size

`desktop_app.py`, near the bottom of `main()`:

```python
_WINDOW_REF = webview.create_window(
    title       = "Secure Eye Trust+",
    url         = initial_url,
    width       = 1400,         # ← change me
    height      = 900,          # ← change me
    min_size    = (1280, 800),
    resizable   = False,        # ← True = let the user resize
    ...
)
```

The dashboard's existing CSS is responsive enough to handle anything
from 1280×800 up to 1920×1080.

---

## 10. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `❌ pyinstaller failed: ModuleNotFoundError: api.foo` | Add `api.foo` to the `hiddenimports` list in `Secure_Eye_Trust.spec` |
| `.exe` opens, then nothing happens | Change `console = False` to `True` in the spec and rebuild — you'll see a console window with errors |
| UAC prompt does not appear | Verify `app.manifest` is referenced in the spec (`manifest='app.manifest'`) and `uac_admin=True` is set |
| `dist/Secure_Eye_Trust.exe is 800 MB` | Install UPX (see step 1) — that cuts ~40%. Or switch to `onefile=False` so files compress in transit instead |
| First launch hangs >30 s | One-file mode extracts to `%TEMP%` on every launch. Use `onefile=False` + the NSIS installer route described below |
| Tray icon does not appear | Some Windows builds collapse new icons. Click the `^` arrow in the taskbar to expand the overflow tray |
| Auto-login keeps failing silently | Open `%LOCALAPPDATA%\SecureEyeTrust\session.json`, delete it, and sign in again — the password may have been changed in Firebase |

---

## 11. (Optional) Wrap into a single installer .exe

For a clean Add/Remove Programs entry, use [NSIS](https://nsis.sourceforge.io/):

1. Build with `onefile = False` in the spec (faster startup).
2. Use the NSIS script template below — save as `installer.nsi`,
   then `makensis installer.nsi` produces `SetupSecureEyeTrust.exe`:

```nsi
!define APPNAME "Secure Eye Trust+"
!define COMPANY "YourCompany"
!define VERSION "1.0.0"

Name "${APPNAME}"
OutFile "SetupSecureEyeTrust.exe"
InstallDir "$PROGRAMFILES64\${APPNAME}"
RequestExecutionLevel admin

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "dist\Secure_Eye_Trust\*"
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\Secure_Eye_Trust.exe"
  CreateShortcut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\Secure_Eye_Trust.exe"
  WriteUninstaller "$INSTDIR\uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  RMDir /r "$INSTDIR"
SectionEnd
```

---

## 12. Code-protection levels — pick one

| Level | Tool | How to use | Pros | Cons |
|---|---|---|---|---|
| 1 — None | PyInstaller `build.bat` | Default | Fastest startup | Source is recoverable via `pyinstxtractor` + `uncompyle6` |
| 2 — PyArmor | `build_protected.bat` | This package | Source is encrypted bytecode; very hard to reverse | +10–20 s startup; free tier has 30-day trial; paid is ~$70/yr |
| 3 — Nuitka | `pip install nuitka` then `python -m nuitka --standalone --onefile --windows-uac-admin desktop_app.py` | Replaces PyInstaller | Compiles to real native C — essentially uncrackable | Build takes ~30 min; larger debugging surface |

For a commercial product **level 2 or 3** is strongly recommended.

---

You now have a complete, redistributable, code-protected, auto-login,
admin-elevated, always-on-in-the-background desktop edition of Secure
Eye Trust+. Ship it.

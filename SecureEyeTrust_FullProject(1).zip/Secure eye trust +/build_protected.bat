@echo off
title Secure Eye Trust+ Build (Protected)
cd /d "%~dp0"

echo.
echo  ============================================================
echo    Secure Eye Trust+  -  PROTECTED build (with PyArmor)
echo  ============================================================
echo    Folder: %CD%
echo  ============================================================
echo.
echo  This window will stay open until you close it manually.
echo  Even if something fails, you will be able to read the error.
echo.

if not exist build_protected.py (
    echo  [ERROR] build_protected.py is not in this folder.
    echo          Drop it next to app.py and try again.
    goto :END
)

if not exist app.py (
    echo  [ERROR] app.py is not in this folder.
    echo          Run this .bat from your project root,
    echo          not from a different folder.
    goto :END
)

echo  [INFO] Checking Python ...
python --version
if errorlevel 1 (
    echo.
    echo  [ERROR] Python is not on your PATH.
    echo          Install Python 3.11 from https://python.org
    echo          and tick "Add python.exe to PATH" while installing.
    goto :END
)

echo.
echo  [INFO] Handing off to Python orchestrator ...
echo  ------------------------------------------------------------
echo.

python build_protected.py

echo.
echo  ------------------------------------------------------------
echo  [INFO] Python orchestrator finished with exit code %errorlevel%
echo.

:END
echo.
echo  ============================================================
echo   The window will remain open. Press any key to close it.
echo  ============================================================
pause >nul

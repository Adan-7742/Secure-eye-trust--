"""
api/auth_desktop_api.py — Secure Eye Trust+
============================================
Two endpoints for the desktop launcher:

  GET  /desktop-autologin?token=XXX
       Consumes a one-time handshake token issued by desktop_app.py,
       sets the Flask session as if the user logged in normally, and
       redirects to the dashboard root '/'.

  POST /api/auth/remember-me
       Called by the login page's JS right after a successful sign-in
       to ask Secure Eye Trust+ to remember the credentials for future
       launches. Stored via utils.credentials (Windows Credential Mgr).

  POST /api/auth/forget-me
       Removes saved credentials. The existing /api/auth/logout will
       also call this so logout always wipes the saved creds.
"""
from __future__ import annotations

import sys
import secrets
from datetime import datetime
from flask import Blueprint, request, jsonify, redirect, session

desktop_auth_bp = Blueprint("desktop_auth", __name__)


# ─────────────────────────────────────────────────────────────────────────────
@desktop_auth_bp.route("/desktop-autologin")
def desktop_autologin():
    """Consume the one-time token from desktop_app.py and start a session."""
    tok = request.args.get("token", "").strip()
    store = sys.modules.get("__autologin_store__")
    if not tok or store is None:
        return redirect("/login")

    data = store.consume(tok)
    if not data:
        return redirect("/login")

    # Mirror what set_firebase_session() / do_login() do in api/auth_api.py
    try:
        session.permanent          = True
        session["authenticated"]   = True
        session["uid"]             = data.get("uid", "")
        session["email"]           = data["email"]
        session["username"]        = data["email"].split("@")[0]
        session["id_token"]        = data.get("id_token", "")
        session["login_time"]      = datetime.now().isoformat()
        session["session_id"]      = secrets.token_hex(16)
        session["auth_method"]     = "firebase"
        session["desktop_session"] = True   # marker for UI
    except Exception:
        return redirect("/login")

    return redirect("/")


# ─────────────────────────────────────────────────────────────────────────────
@desktop_auth_bp.route("/api/auth/remember-me", methods=["POST"])
def remember_me():
    """Persist current login so the next .exe launch auto-logs in.
    Body: {email, password}.  Caller should only invoke this on a
    successful sign-in (i.e. directly after /api/auth/login returns ok)."""
    d  = request.get_json(silent=True) or {}
    em = (d.get("email")    or "").strip().lower()
    pw = (d.get("password") or "").strip()
    if not em or not pw:
        return jsonify({"ok": False, "error": "email & password required"}), 400
    # Only allow saving credentials for the email that is *currently* in session
    sess_em = (session.get("email") or "").lower()
    if sess_em and sess_em != em:
        return jsonify({"ok": False, "error": "session mismatch"}), 403
    try:
        from utils.credentials import save_credentials
        ok = save_credentials(em, pw)
        return jsonify({"ok": bool(ok)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ─────────────────────────────────────────────────────────────────────────────
@desktop_auth_bp.route("/api/auth/forget-me", methods=["POST"])
def forget_me():
    """Wipe saved credentials. Safe to call even if none exist."""
    try:
        from utils.credentials import clear_credentials
        clear_credentials()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ─────────────────────────────────────────────────────────────────────────────
@desktop_auth_bp.route("/api/auth/has-saved-creds")
def has_saved_creds():
    """Helper used by the login UI to show a 'Remember me is already on' badge."""
    try:
        from utils.credentials import has_credentials
        return jsonify({"saved": bool(has_credentials())})
    except Exception:
        return jsonify({"saved": False})

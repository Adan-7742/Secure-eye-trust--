"""
desktop_app.py — Secure Eye Trust+ Desktop Launcher
====================================================
Wraps the existing Flask app inside a fixed-size native desktop window,
runs background monitors continuously, supports auto-login from saved
credentials, system-tray minimization, and admin elevation.

Build target: PyInstaller --onefile bundle that becomes Secure_Eye_Trust.exe
"""
from __future__ import annotations

import os
import sys
import time
import socket
import secrets
import threading
import traceback
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# 0)  PyInstaller bootstrap — detect frozen mode & resolve resource paths
# ─────────────────────────────────────────────────────────────────────────────
def _is_frozen() -> bool:
    return getattr(sys, "frozen", False)

def _resource_dir() -> Path:
    """Where bundled read-only resources live (templates, static, rules)."""
    if _is_frozen():
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent

def _user_data_dir() -> Path:
    """Where writable user data lives (databases, logs, keys, captures)."""
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    else:
        base = Path.home() / ".local" / "share"
    d = base / "SecureEyeTrust"
    d.mkdir(parents=True, exist_ok=True)
    return d

RESOURCE_DIR = _resource_dir()
USER_DATA    = _user_data_dir()

# Make sure Python can find our packages when frozen
sys.path.insert(0, str(RESOURCE_DIR))
os.chdir(str(RESOURCE_DIR))


# ─────────────────────────────────────────────────────────────────────────────
# 1)  Admin elevation — re-launch as Administrator if not already
# ─────────────────────────────────────────────────────────────────────────────
def _is_admin() -> bool:
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

def _elevate_and_exit():
    """Re-launch the current executable with admin rights, then exit."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        exe    = sys.executable
        params = " ".join(f'"{a}"' for a in sys.argv[1:])
        # ShellExecuteW with the 'runas' verb triggers the UAC prompt
        rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, None, 1)
        # rc <= 32 means launch failed (user clicked No or error)
        if rc <= 32:
            print("[admin] Elevation cancelled — running with reduced privileges.")
            return
        # Successful elevation — quit this non-elevated instance
        os._exit(0)
    except Exception as e:
        print(f"[admin] elevation error: {e}")

# If the UAC manifest in the PyInstaller .spec is set to requireAdministrator
# Windows will already have elevated us automatically. This is a safety net.
if not _is_admin() and "--no-admin" not in sys.argv:
    _elevate_and_exit()


# ─────────────────────────────────────────────────────────────────────────────
# 2)  Redirect database & log paths to %LOCALAPPDATA%\SecureEyeTrust
#     (PyInstaller temp dir is read-only / wiped on exit)
# ─────────────────────────────────────────────────────────────────────────────
def _redirect_db_paths():
    db_dir = USER_DATA / "database"
    db_dir.mkdir(parents=True, exist_ok=True)

    # Import the database modules and patch their module-level path constants.
    # All other modules call get_conn() which re-reads these constants, so this
    # is enough — no need to touch every API file.
    try:
        import database.db as _maindb
        _maindb.DB_PATH = str(db_dir / "logs.db")
    except Exception as e:
        print(f"[paths] could not patch database.db: {e}")

    try:
        import database.uploads_db as _udb
        _udb._DB_PATH = str(db_dir / "uploads.db")
    except Exception as e:
        print(f"[paths] could not patch uploads_db: {e}")

    try:
        import database.locker_db as _ldb
        _ldb._DB_PATH = db_dir / "locker.db"
    except Exception as e:
        print(f"[paths] could not patch locker_db: {e}")

    # Keys dir
    keys_dir = USER_DATA / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("SET_KEYS_DIR", str(keys_dir))

    print(f"[paths] user data dir: {USER_DATA}")

_redirect_db_paths()


# ─────────────────────────────────────────────────────────────────────────────
# 3)  Pick a free localhost port for Flask
# ─────────────────────────────────────────────────────────────────────────────
def _free_port(preferred: int = 5000) -> int:
    for p in (preferred, *range(5001, 5100)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return preferred

PORT = _free_port(int(os.environ.get("PORT", "5000")))
os.environ["PORT"] = str(PORT)
APP_URL = f"http://127.0.0.1:{PORT}"


# ─────────────────────────────────────────────────────────────────────────────
# 4)  In-memory one-time-token store for auto-login (set + consumed by Flask)
# ─────────────────────────────────────────────────────────────────────────────
class _AutoLoginStore:
    """A trivial in-memory token vault for the desktop-autologin handshake."""
    _lock   = threading.Lock()
    _tokens: dict[str, dict] = {}

    @classmethod
    def issue(cls, email: str, uid: str, id_token: str) -> str:
        tok = secrets.token_urlsafe(32)
        with cls._lock:
            cls._tokens[tok] = {"email": email, "uid": uid, "id_token": id_token,
                                "ts": time.time()}
        return tok

    @classmethod
    def consume(cls, tok: str):
        with cls._lock:
            data = cls._tokens.pop(tok, None)
        if not data: return None
        if time.time() - data["ts"] > 60: return None  # 60-second TTL
        return data

# Expose to the Flask blueprint via sys.modules so they share the same object
sys.modules["__autologin_store__"] = _AutoLoginStore  # type: ignore[assignment]


# ─────────────────────────────────────────────────────────────────────────────
# 5)  Start Flask in a background thread (re-uses existing app.py init)
# ─────────────────────────────────────────────────────────────────────────────
def _start_flask():
    """Mirror app.py's __main__ initialisation, then serve forever."""
    try:
        # Init databases ------------------------------------------------------
        from database.db          import init_db
        from database.uploads_db  import init_uploads_db
        init_db()
        init_uploads_db()

        # Optional schema fixups (same as app.py) -----------------------------
        for _setup, label in [
            ("core.event_collector.sysmon_collector._ensure_sysmon_table",  "sysmon"),
            ("core.analysis_engine.sigma_engine._ensure_sigma_table",       "sigma"),
            ("core.event_collector.file_scanner._ensure_scan_table",        "filescan"),
        ]:
            try:
                mod, fn = _setup.rsplit(".", 1)
                getattr(__import__(mod, fromlist=[fn]), fn)()
                print(f"  ✅ {label} table ready")
            except Exception as e:
                print(f"  ⚠  {label} table: {e}")

        # Background worker / pipeline ---------------------------------------
        try:
            from core.pipeline.worker       import get_worker
            from core.pipeline.orchestrator import get_pipeline
            get_worker()
            get_pipeline()
            print("  ✅ Background worker + pipeline up")
        except Exception as e:
            print(f"  ⚠  pipeline init: {e}")

        # FR04 threat rules patch --------------------------------------------
        try:
            from core.analysis_engine.threat_detector_fr04_patch import apply_patch_to_threat_rules
            from core.analysis_engine import threat_detector as _td
            _td.THREAT_RULES = apply_patch_to_threat_rules(_td.THREAT_RULES)
        except Exception as e:
            print(f"  ⚠  FR04 patch skipped: {e}")

        # Windows monitors (only when admin + pywin32 present) ---------------
        try:
            from core.event_collector.windows_reader import WIN32_AVAILABLE
        except Exception:
            WIN32_AVAILABLE = False

        if WIN32_AVAILABLE:
            try:
                from core.event_collector.rt_pipeline import get_rt_pipeline
                get_rt_pipeline().start()
                print("  ✅ Real-Time Pipeline started")
            except Exception:
                try:
                    from core.event_collector.live_monitor import start_live_monitor
                    start_live_monitor()
                except Exception as e:
                    print(f"  ⚠  live monitor: {e}")

            for _start, lbl in [
                ("core.event_collector.winlogin_watcher.start_winlogin_watcher", "login watcher"),
                ("core.event_collector.task_scheduler_monitor.get_task_monitor", "task scheduler"),
                ("core.event_collector.service_monitor.get_service_monitor",    "service monitor"),
                ("core.event_collector.usb_monitor.start_usb_monitor",          "usb monitor"),
            ]:
                try:
                    mod, fn = _start.rsplit(".", 1)
                    res = getattr(__import__(mod, fromlist=[fn]), fn)()
                    # Some return objects with .start(), others run directly
                    if res is not None and hasattr(res, "start"):
                        res.start()
                    print(f"  ✅ {lbl} started")
                except Exception as e:
                    print(f"  ⚠  {lbl}: {e}")

        # Scheduled analysis -------------------------------------------------
        try:
            from api.perform_analysis_api import _start_scheduler
            _start_scheduler()
        except Exception as e:
            print(f"  ⚠  scheduler: {e}")

        # Build Flask app + register desktop auto-login blueprint ------------
        from app import create_app
        application = create_app()

        # Plug in our auto-login + remember-me blueprint
        try:
            from api.auth_desktop_api import desktop_auth_bp
            application.register_blueprint(desktop_auth_bp, url_prefix="")
            print("  ✅ desktop auth blueprint registered")
        except Exception as e:
            print(f"  ⚠  desktop auth bp: {e}")

        application.run(host="127.0.0.1", port=PORT,
                        debug=False, threaded=True, use_reloader=False)
    except Exception:
        traceback.print_exc()
        # Keep alive so the user can read the error in the console window
        time.sleep(15)


# ─────────────────────────────────────────────────────────────────────────────
# 6)  Wait for the Flask server to become ready
# ─────────────────────────────────────────────────────────────────────────────
def _wait_for_server(timeout: float = 25.0) -> bool:
    import urllib.request, urllib.error
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"{APP_URL}/api/auth/firebase-status", timeout=1)
            return True
        except Exception:
            time.sleep(0.25)
    return False


# ─────────────────────────────────────────────────────────────────────────────
# 7)  Auto-login attempt — read saved creds, validate, issue handshake token
# ─────────────────────────────────────────────────────────────────────────────
def _build_initial_url() -> str:
    """If we have saved credentials, validate and produce an auto-login URL.
    Otherwise return the plain root URL (which will redirect to /login)."""
    try:
        from utils.credentials import load_credentials
        creds = load_credentials()
        if not creds:
            return f"{APP_URL}/"

        from firebase_auth import firebase_login, firebase_configured
        if firebase_configured():
            r = firebase_login(creds["email"], creds["password"])
            if r.get("ok"):
                tok = _AutoLoginStore.issue(r["email"], r["uid"], r["idToken"])
                print(f"  ✅ auto-login ready for {r['email']}")
                return f"{APP_URL}/desktop-autologin?token={tok}"
            else:
                # Saved creds no longer work — wipe and force fresh login
                try:
                    from utils.credentials import clear_credentials
                    clear_credentials()
                except Exception:
                    pass
        return f"{APP_URL}/"
    except Exception as e:
        print(f"[auto-login] {e}")
        return f"{APP_URL}/"


# ─────────────────────────────────────────────────────────────────────────────
# 8)  System-tray icon — keeps the app alive in the background after window close
# ─────────────────────────────────────────────────────────────────────────────
_TRAY_ICON = None
_WINDOW_REF = None

def _start_tray():
    global _TRAY_ICON
    try:
        import pystray
        from PIL import Image, ImageDraw

        # Try to load bundled icon; fall back to a generated shield glyph
        icon_path = RESOURCE_DIR / "app_icon.png"
        if icon_path.exists():
            img = Image.open(icon_path)
        else:
            img = Image.new("RGB", (64, 64), (15, 26, 46))
            d   = ImageDraw.Draw(img)
            d.rectangle((10, 6, 54, 50), fill=(26, 140, 255))
            d.text((22, 16), "S", fill=(255, 255, 255))

        def _show(icon, item):
            try:
                if _WINDOW_REF is not None:
                    _WINDOW_REF.show()
            except Exception:
                pass

        def _quit(icon, item):
            try:
                icon.stop()
            finally:
                os._exit(0)

        menu = pystray.Menu(
            pystray.MenuItem("Open Dashboard", _show, default=True),
            pystray.MenuItem("Quit Secure Eye Trust+", _quit),
        )
        _TRAY_ICON = pystray.Icon("SecureEyeTrust", img,
                                  "Secure Eye Trust+ (running)", menu)
        threading.Thread(target=_TRAY_ICON.run, daemon=True).start()
        print("  ✅ system tray icon started")
    except Exception as e:
        print(f"  ⚠  tray: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 9)  Main — start Flask, wait, open fixed-size webview window
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 62)
    print("  🔐  Secure Eye Trust+  —  Desktop Edition")
    print("=" * 62)
    print(f"  User data : {USER_DATA}")
    print(f"  Admin     : {'YES' if _is_admin() else 'NO'}")
    print(f"  URL       : {APP_URL}")
    print("=" * 62)

    # Spawn Flask in background
    flask_thr = threading.Thread(target=_start_flask, daemon=True,
                                 name="flask-server")
    flask_thr.start()

    # Wait until it's ready
    if not _wait_for_server():
        print("❌ Flask did not start in time.  Check logs above.")
        time.sleep(20)
        return 1

    # Tray icon (so closing the window keeps analysis running)
    _start_tray()

    # Build the URL — auto-login if we have stored credentials
    initial_url = _build_initial_url()

    # Fixed-size native window via pywebview ---------------------------------
    import webview

    def _on_closed():
        # When user clicks the X, do NOT exit — minimize to tray
        # (pywebview's confirm_close=False already destroys the window;
        # we re-create on tray "Open Dashboard")
        pass

    global _WINDOW_REF
    _WINDOW_REF = webview.create_window(
        title       = "Secure Eye Trust+",
        url         = initial_url,
        width       = 1400,
        height      = 900,
        min_size    = (1280, 800),
        resizable   = False,         # ← fixed-size dashboard, as requested
        confirm_close = False,
        background_color = "#060c1a",
    )
    _WINDOW_REF.events.closed += _on_closed  # keep tray running

    # Start the GUI loop — blocks until window is closed
    webview.start(debug=False, http_server=False)

    # Window closed — the tray thread keeps the process alive.
    # Block here so background analysis keeps running.
    print("[main] window closed — background analysis continues (right-click tray icon to quit)")
    while True:
        time.sleep(60)

    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)

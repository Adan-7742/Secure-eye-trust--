# -*- mode: python ; coding: utf-8 -*-
"""
Secure_Eye_Trust.spec — PyInstaller build script
=================================================
Run with:  pyinstaller --noconfirm Secure_Eye_Trust.spec
Produces:  dist/Secure_Eye_Trust.exe   (single file, ~250-400 MB)

Tip — to compile to one *folder* (faster startup), change `onefile=True`
to `onefile=False` near the bottom of this file.
"""
import os
import sys
from pathlib import Path

block_cipher = None
HERE = Path(os.getcwd())   # run pyinstaller from project root

# ─── Bundled data files (templates, static assets, rules, .env) ─────────────
datas = []
def _add(src, dst):
    p = HERE / src
    if p.exists():
        datas.append((str(p), dst))

# templates & static assets
_add("templates", "templates")
_add("static",    "static")
_add("rules",     "rules")
_add("keys",      "keys")       # initial keystore.json (will be migrated to %LOCALAPPDATA%)
_add(".env",      ".")          # ship a default .env (replace with the real one before build!)
_add("app_icon.ico", ".")
_add("app_icon.png", ".")

# IMPORTANT: do NOT bundle the giant databases. They will be (re)created
# inside %LOCALAPPDATA%\SecureEyeTrust\database on first launch.

# ─── Hidden imports — PyInstaller can't statically see Flask blueprints ─────
hiddenimports = [
    # Project blueprints (every file under api/ that registers a blueprint)
    'api', 'api.auth_api', 'api.auth_desktop_api', 'api.system_api',
    'api.locker_api', 'api.reports_api', 'api.logs_api', 'api.analysis_api',
    'api.upload_api', 'api.realtime_api', 'api.network_api',
    'api.analyze_upload_api', 'api.upload_report_pdf_api',
    'api.perform_analysis_api', 'api.ai_narrative_api', 'api.analysis_ai_api',
    'api.intelligence_api', 'api.alerts_api', 'api.fetch_api',
    'api.log_explain_api', 'api.error_stream_api', 'api.alerts_resolve_api',
    'api.rt_status_api', 'api.windows_integration_api', 'api.fr11_health_api',
    'api.rag_analysis_api', 'api.timeseries_api', 'api.sysmon_api',
    'api.response_actions_api', 'api.fix_all_api', 'api.threat_actions_api',
    'api.chat_api', 'api.bitlocker_api', 'api.auto_fix_api',
    'api.malware_analysis_api', 'api.status_api', 'api.alert_bus_patch',
    'api.ai_narrative', 'api.analyze_api',

    # Core engine modules (loaded dynamically by name)
    'core', 'core.event_collector', 'core.analysis_engine', 'core.pipeline',
    'core.ml_engine', 'core.he_engine', 'core.folder_lock',
    'core.key_management', 'core.fim_engine',
    'core.event_collector.windows_reader',
    'core.event_collector.live_monitor',
    'core.event_collector.winlogin_watcher',
    'core.event_collector.task_scheduler_monitor',
    'core.event_collector.service_monitor',
    'core.event_collector.rt_pipeline',
    'core.event_collector.usb_monitor',
    'core.event_collector.sysmon_collector',
    'core.event_collector.file_scanner',
    'core.analysis_engine.sigma_engine',
    'core.analysis_engine.threat_detector',
    'core.analysis_engine.threat_detector_fr04_patch',
    'core.pipeline.worker',
    'core.pipeline.orchestrator',

    # Chatbot, services, utils
    'chatbot', 'chatbot.bot', 'chatbot.context_builder', 'chatbot.offline_engine',
    'services', 'services.rag_service',
    'utils', 'utils.credentials', 'utils.admin_check',
    'utils.helpers', 'utils.logger', 'utils.security',

    # Database
    'database', 'database.db', 'database.uploads_db', 'database.locker_db',
    'database.db_sysmon_patch', 'database.he_migration', 'database.schema_pg',

    # Firebase / auth
    'firebase_auth',

    # Third-party packages PyInstaller sometimes misses
    'flask', 'flask_cors', 'werkzeug', 'jinja2', 'click', 'itsdangerous',
    'requests', 'urllib3', 'charset_normalizer', 'idna', 'certifi',
    'dotenv',
    'psutil',
    'mss', 'mss.windows',
    'PIL', 'PIL.Image', 'PIL.ImageDraw',
    'reportlab', 'reportlab.lib', 'reportlab.platypus', 'reportlab.pdfgen',
    'webview', 'webview.platforms', 'webview.platforms.winforms',
    'pystray', 'pystray._win32',
    'keyring', 'keyring.backends', 'keyring.backends.Windows',
    'win32api', 'win32con', 'win32event', 'win32service', 'win32serviceutil',
    'win32com', 'win32com.client', 'pywintypes', 'pythoncom',
    'wmi',
]

# ─── Build the Analysis tree ────────────────────────────────────────────────
a = Analysis(
    ['desktop_app.py'],
    pathex=[str(HERE)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Trim space — these come along for the ride but aren't needed
        'tkinter', 'matplotlib.tests', 'scipy.tests', 'numpy.tests',
        'pandas.tests', 'IPython', 'jupyter', 'pytest', 'unittest',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ─── Build mode: True = one-file (slower start), False = one-folder ─────────
onefile = True

if onefile:
    exe = EXE(
        pyz,
        a.scripts, a.binaries, a.zipfiles, a.datas, [],
        name        = 'Secure_Eye_Trust',
        debug       = False,
        bootloader_ignore_signals = False,
        strip       = False,
        upx         = True,            # set False if you don't have UPX
        upx_exclude = [],
        runtime_tmpdir   = None,
        console     = False,           # ← True if you want the debug console window
        disable_windowed_traceback = False,
        argv_emulation = False,
        target_arch = None,
        codesign_identity = None,
        entitlements_file = None,
        icon        = 'app_icon.ico' if (HERE / 'app_icon.ico').exists() else None,
        manifest    = 'app.manifest',  # ← requests admin (UAC) on launch
        uac_admin   = True,
        version     = None,
    )
else:
    exe = EXE(
        pyz, a.scripts, [],
        exclude_binaries = True,
        name        = 'Secure_Eye_Trust',
        debug       = False,
        bootloader_ignore_signals = False,
        strip       = False,
        upx         = True,
        console     = False,
        icon        = 'app_icon.ico' if (HERE / 'app_icon.ico').exists() else None,
        manifest    = 'app.manifest',
        uac_admin   = True,
    )
    coll = COLLECT(
        exe, a.binaries, a.zipfiles, a.datas,
        strip=False, upx=True, upx_exclude=[], name='Secure_Eye_Trust',
    )

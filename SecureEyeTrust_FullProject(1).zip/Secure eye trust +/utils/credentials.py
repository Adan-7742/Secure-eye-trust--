"""
utils/credentials.py — Secure credential storage for Secure Eye Trust+
=======================================================================
Stores the user's login (email + password) in the Windows Credential
Manager, encrypted per-user via DPAPI under the hood.

We *also* keep a JSON pointer file so we know which account was saved,
without touching the password.

WHY keyring?
  - On Windows it transparently uses Credential Locker (DPAPI per-user
    encryption — another user on the same PC cannot read it).
  - On macOS it uses Keychain; on Linux it uses Secret Service.
  - No password leaves the local machine.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

# ── Where the *pointer* file lives (NOT the password itself) ─────────────────
def _user_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA",
                                    str(Path.home() / "AppData" / "Local")))
    else:
        base = Path.home() / ".local" / "share"
    d = base / "SecureEyeTrust"
    d.mkdir(parents=True, exist_ok=True)
    return d

_POINTER = _user_dir() / "session.json"
_SERVICE = "SecureEyeTrustPlus"


# ─────────────────────────────────────────────────────────────────────────────
def _keyring():
    """Lazy keyring import — keyring is optional and may not be present in dev."""
    try:
        import keyring  # type: ignore
        return keyring
    except Exception:
        return None


def save_credentials(email: str, password: str) -> bool:
    """Store credentials so the next launch can auto-login.
    Returns True if stored successfully."""
    if not email or not password:
        return False
    kr = _keyring()
    if kr is None:
        # Fallback (less secure): write to JSON. Warn the user via log.
        try:
            _POINTER.write_text(json.dumps({"email": email,
                                            "password_fallback": password}))
            print("[credentials] WARN — keyring missing; using JSON fallback.")
            return True
        except Exception as e:
            print(f"[credentials] save failed: {e}")
            return False
    try:
        kr.set_password(_SERVICE, email, password)
        _POINTER.write_text(json.dumps({"email": email}))
        return True
    except Exception as e:
        print(f"[credentials] save failed: {e}")
        return False


def load_credentials() -> Optional[dict]:
    """Return {email, password} or None if no saved creds."""
    if not _POINTER.exists():
        return None
    try:
        data  = json.loads(_POINTER.read_text() or "{}")
        email = data.get("email")
        if not email:
            return None

        # Fallback path (no keyring)
        if "password_fallback" in data:
            return {"email": email, "password": data["password_fallback"]}

        kr = _keyring()
        if kr is None:
            return None
        pw = kr.get_password(_SERVICE, email)
        if not pw:
            return None
        return {"email": email, "password": pw}
    except Exception as e:
        print(f"[credentials] load failed: {e}")
        return None


def clear_credentials() -> bool:
    """Forget saved credentials (called on logout / failed auto-login)."""
    try:
        if _POINTER.exists():
            try:
                data  = json.loads(_POINTER.read_text() or "{}")
                email = data.get("email")
                kr    = _keyring()
                if kr and email:
                    try:
                        kr.delete_password(_SERVICE, email)
                    except Exception:
                        pass
            finally:
                try: _POINTER.unlink()
                except Exception: pass
        return True
    except Exception as e:
        print(f"[credentials] clear failed: {e}")
        return False


def has_credentials() -> bool:
    return _POINTER.exists()

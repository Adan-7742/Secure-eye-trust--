"""
install_autostart.py — Register Secure Eye Trust+ as a Windows auto-start task
==============================================================================
Run this ONCE after first launch. It creates a Windows Scheduled Task that
launches Secure_Eye_Trust.exe at user login with the "Run with highest
privileges" flag set. After that:

  • UAC no longer prompts on every launch (the task already runs elevated)
  • The app starts automatically when Windows boots
  • Background monitors run continuously even before the user opens the window

Uninstall with:
    python install_autostart.py --remove
"""
from __future__ import annotations

import argparse
import ctypes
import getpass
import os
import subprocess
import sys
from pathlib import Path

TASK_NAME = "SecureEyeTrustPlus_AutoStart"


def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _elevate():
    """Re-launch this script with UAC if not already elevated."""
    params = " ".join(f'"{a}"' for a in sys.argv)
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)


def install(exe_path: Path):
    user = os.environ.get("USERNAME") or getpass.getuser()
    print(f"  • Registering '{TASK_NAME}' for user '{user}'")
    print(f"  • EXE:   {exe_path}")

    # /SC ONLOGON   = trigger at user login
    # /RL HIGHEST   = run with highest privileges (no UAC prompt)
    # /F            = overwrite existing task with same name
    cmd = [
        "schtasks", "/Create",
        "/TN", TASK_NAME,
        "/SC", "ONLOGON",
        "/RL", "HIGHEST",
        "/TR", f'"{exe_path}"',
        "/F",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("❌ Could not create scheduled task:")
        print(result.stdout)
        print(result.stderr)
        sys.exit(1)
    print("✅ Auto-start task created.")
    print("   The app will launch automatically next time you sign in.")
    print("   No more UAC prompts on launch.")


def remove():
    result = subprocess.run(
        ["schtasks", "/Delete", "/TN", TASK_NAME, "/F"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        print(f"✅ Removed auto-start task '{TASK_NAME}'.")
    else:
        print("⚠  Could not remove task (it may already be gone):")
        print(result.stderr)


def main():
    p = argparse.ArgumentParser(description="Install/remove Secure Eye Trust+ auto-start")
    p.add_argument("--remove", action="store_true",
                   help="Uninstall the auto-start task")
    p.add_argument("--exe", default="",
                   help="Path to Secure_Eye_Trust.exe (default: alongside this script)")
    args = p.parse_args()

    if not _is_admin():
        print("[admin] elevating ...")
        _elevate()
        return

    if args.remove:
        remove()
        return

    exe = Path(args.exe) if args.exe else Path(sys.executable).parent / "Secure_Eye_Trust.exe"
    if not exe.exists():
        # Maybe we're being run from source — look in dist/
        guess = Path(__file__).resolve().parent / "dist" / "Secure_Eye_Trust.exe"
        if guess.exists():
            exe = guess
    if not exe.exists():
        print(f"❌ Cannot find Secure_Eye_Trust.exe (tried {exe}).")
        print("   Pass the path explicitly:  install_autostart.py --exe C:\\path\\to\\Secure_Eye_Trust.exe")
        sys.exit(1)

    install(exe)


if __name__ == "__main__":
    main()

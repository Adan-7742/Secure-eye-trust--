"""
build_protected.py
==================
Cross-mode build orchestrator for Secure Eye Trust+.

Called by both build.bat (plain mode) and build_protected.bat (PyArmor mode).
Reads SET_BUILD_MODE env var:
    "plain"     -> skip PyArmor, run PyInstaller directly on the source
    anything    -> default = PyArmor obfuscation, then PyInstaller

Design rules:
  * Pure ASCII output, no Unicode glyphs, so it always renders in cmd.exe
  * Every external command goes through run() which captures stdout/stderr
    and NEVER raises -- caller gets (returncode, output) tuple
  * Top-level try/except prevents the script from ever crashing silently
  * Always pauses at the very end (the .bat also pauses as a belt-and-braces)
"""
from __future__ import annotations

import os
import sys
import shutil
import subprocess
import time
import traceback
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
ROOT       = Path.cwd().resolve()
LOG_FILE   = ROOT / "build_log.txt"
MODE       = (os.environ.get("SET_BUILD_MODE") or "").strip().lower() or "protected"
WARN_LOG   = []
ERR_LOG    = []
START_TIME = time.time()


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _stamp() -> str:
    return datetime.now().strftime("%H:%M:%S")

def log(msg: str, level: str = "INFO") -> None:
    line = f"[{_stamp()}] [{level:<5}] {msg}"
    try:
        print(line, flush=True)
    except Exception:
        # If even print breaks (encoding hell), write to stderr in latin-1
        try:
            sys.stderr.buffer.write((line + "\n").encode("latin-1", "replace"))
        except Exception:
            pass
    try:
        with LOG_FILE.open("a", encoding="utf-8") as fp:
            fp.write(line + "\n")
    except Exception:
        pass

def info(msg):  log(msg, "INFO")
def warn(msg):  log(msg, "WARN");  WARN_LOG.append(msg)
def err(msg):   log(msg, "ERROR"); ERR_LOG.append(msg)

def banner(text: str) -> None:
    line = "-" * 64
    log(line, "STEP")
    log("  " + text, "STEP")
    log(line, "STEP")


# ---------------------------------------------------------------------------
# Subprocess wrapper -- never raises, always returns (rc, output)
# ---------------------------------------------------------------------------
def run(cmd, *, cwd: Path | None = None, retries: int = 0,
        env: dict | None = None) -> tuple[int, str]:
    if isinstance(cmd, str):
        printable, shell = cmd, True
    else:
        printable = " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd)
        shell = False

    attempt = 0
    while True:
        attempt += 1
        suffix = f"   (attempt {attempt})" if attempt > 1 else ""
        log(f"$ {printable}{suffix}", "EXEC")
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(cwd) if cwd else None,
                shell=shell,
                env={**os.environ, **(env or {})},
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError as e:
            err(f"command not found: {e}")
            return 127, str(e)
        except Exception as e:
            err(f"subprocess error: {e}")
            return 1, str(e)

        out = (proc.stdout or "") + (proc.stderr or "")
        for line in out.splitlines():
            s = line.rstrip()
            if s:
                log("  | " + s, "OUT")

        if proc.returncode == 0 or attempt > retries:
            return proc.returncode, out
        warn(f"  -> exit code {proc.returncode}, retrying in 2s ...")
        time.sleep(2)


# ---------------------------------------------------------------------------
# Phase 1 -- Pre-flight
# ---------------------------------------------------------------------------
def preflight() -> bool:
    banner("STEP 1  -  Pre-flight checks")
    ok = True

    v = sys.version_info
    if v < (3, 9):
        err(f"Python {v.major}.{v.minor} is too old (need 3.9+, 3.11 recommended)")
        ok = False
    else:
        info(f"Python {v.major}.{v.minor}.{v.micro}  [ok]")

    rc, _ = run([sys.executable, "-m", "pip", "--version"])
    if rc != 0:
        err("pip is not working.  Fix with:  python -m ensurepip --upgrade")
        ok = False

    required = [
        "app.py", "desktop_app.py", "firebase_auth.py",
        "Secure_Eye_Trust.spec", "app.manifest", "requirements_build.txt",
        "api/auth_desktop_api.py", "utils/credentials.py",
    ]
    for f in required:
        if not (ROOT / f).exists():
            err(f"missing required file: {f}")
            ok = False
        else:
            info(f"  [ok]  {f}")

    if not (ROOT / ".env").exists():
        warn(".env not found -- the .exe will run with default settings only. "
             "Add FIREBASE_API_KEY etc. before distributing.")

    try:
        free_gb = shutil.disk_usage(str(ROOT)).free / 1e9
        if free_gb < 3:
            warn(f"only {free_gb:.1f} GB free -- PyInstaller may run out")
        else:
            info(f"free disk: {free_gb:.1f} GB  [ok]")
    except Exception as e:
        warn(f"cannot check disk space: {e}")

    rc, _ = run(["upx", "--version"])
    if rc != 0:
        warn("UPX not in PATH -- the .exe will be ~40% larger. "
             "Get it at https://upx.github.io/  (optional)")
    else:
        info("UPX present  [ok]")

    info(f"build mode: {MODE.upper()}")
    return ok


# ---------------------------------------------------------------------------
# Phase 2 -- Install dependencies
# ---------------------------------------------------------------------------
def install_deps() -> bool:
    banner("STEP 2  -  Install / upgrade build dependencies")

    run([sys.executable, "-m", "pip", "install", "--upgrade",
         "pip", "setuptools", "wheel"], retries=1)

    rc, _ = run([sys.executable, "-m", "pip", "install",
                 "-r", "requirements_build.txt"], retries=2)
    if rc != 0:
        warn("pip install failed -- retrying with --no-cache-dir ...")
        rc, _ = run([sys.executable, "-m", "pip", "install",
                     "--no-cache-dir", "-r", "requirements_build.txt"], retries=1)

    if rc != 0:
        warn("bulk pip install still failed -- trying one package at a time ...")
        all_ok = True
        try:
            with (ROOT / "requirements_build.txt").open(encoding="utf-8") as fp:
                for raw in fp:
                    pkg = raw.split("#")[0].strip()
                    if not pkg or pkg.startswith("-"):
                        continue
                    pkg = pkg.split(";")[0].strip()
                    if not pkg:
                        continue
                    rc, _ = run([sys.executable, "-m", "pip", "install", pkg], retries=1)
                    if rc != 0:
                        err(f"could not install package: {pkg}")
                        all_ok = False
        except Exception as e:
            err(f"reading requirements file: {e}")
            return False
        if not all_ok:
            return False

    if MODE != "plain":
        rc, _ = run([sys.executable, "-m", "pip", "install",
                     "--upgrade", "pyarmor"], retries=2)
        if rc != 0:
            err("PyArmor install failed.  Either fix the network and retry,")
            err("or run plain build.bat (no obfuscation).")
            return False

    info("dependencies installed  [ok]")
    return True


# ---------------------------------------------------------------------------
# Phase 3 -- Clean
# ---------------------------------------------------------------------------
def clean() -> None:
    banner("STEP 3  -  Clean previous build artefacts")
    for d in ("build", "dist", "dist_obf", "__pycache__"):
        p = ROOT / d
        if p.exists():
            try:
                shutil.rmtree(p)
                info(f"removed {d}/")
            except Exception as e:
                warn(f"could not remove {d}/: {e}")
        else:
            info(f"{d}/  -- already absent")


# ---------------------------------------------------------------------------
# Phase 4 -- Obfuscate (skipped in plain mode)
# ---------------------------------------------------------------------------
def _find_pyarmor_invoker() -> list[str] | None:
    """Find a working PyArmor command prefix.

    PyArmor 8/9 has NO pyarmor/__main__.py, so `python -m pyarmor` raises
    'No module named pyarmor.__main__'. The real entry points are:
      1. The pyarmor.exe console script (in <Python>\\Scripts)
      2. `python -m pyarmor.cli`   (modern module-form)
      3. `python -m pyarmor`       (legacy 7.x only)

    We try each one with `--version`; the first that returns rc=0 wins.
    """
    import shutil as _sh
    candidates: list[list[str]] = []

    # 1. pyarmor on PATH
    on_path = _sh.which("pyarmor")
    if on_path:
        candidates.append([on_path])

    # 2. pyarmor.exe in the same Python's Scripts directory
    py_dir = Path(sys.executable).parent
    for exe_path in (
        py_dir / "Scripts" / "pyarmor.exe",
        py_dir / "Scripts" / "pyarmor",
        py_dir / "pyarmor.exe",
        py_dir / "pyarmor",
        # also try the user-base scripts dir (`pip install --user`)
        Path(os.environ.get("APPDATA", "")) / "Python" / "Scripts" / "pyarmor.exe",
    ):
        if exe_path.exists() and [str(exe_path)] not in candidates:
            candidates.append([str(exe_path)])

    # 3. Module forms
    candidates.append([sys.executable, "-m", "pyarmor.cli"])
    candidates.append([sys.executable, "-m", "pyarmor"])

    for inv in candidates:
        rc, out = run(inv + ["--version"])
        if rc == 0:
            # Echo the detected version for the log
            ver = "unknown"
            for tok in out.replace(",", " ").split():
                if tok and tok[0].isdigit():
                    ver = tok
                    break
            info(f"PyArmor invoker FOUND: {' '.join(inv)}   (version {ver})")
            return inv
        else:
            info(f"  invoker did not respond: {' '.join(inv)}")

    return None


def obfuscate() -> bool:
    global MODE     # we may auto-downgrade to "plain" if PyArmor is unusable

    if MODE == "plain":
        banner("STEP 4  -  PyArmor obfuscation  [skipped: plain mode]")
        return True

    banner("STEP 4  -  Obfuscate source with PyArmor")

    out_dir = ROOT / "dist_obf"
    out_dir.mkdir(exist_ok=True)

    py_files = ["desktop_app.py", "app.py", "firebase_auth.py"]
    py_dirs  = ["api", "chatbot", "core", "database", "services", "utils"]
    targets  = [t for t in (py_files + py_dirs) if (ROOT / t).exists()]
    if not targets:
        err("no .py files/dirs found to obfuscate")
        return False
    info(f"targets: {', '.join(targets)}")

    # ── Find a working PyArmor invoker ──────────────────────────────────────
    invoker = _find_pyarmor_invoker()
    if invoker is None:
        warn("=========================================================")
        warn(" Could not find a working PyArmor invoker.")
        warn(" Tried: pyarmor (PATH), Scripts/pyarmor.exe, -m pyarmor.cli,")
        warn("        -m pyarmor.  All failed.")
        warn(" AUTO-FALLBACK: continuing in PLAIN (unprotected) mode so")
        warn(" you still get a working .exe.  Source code WILL be embedded")
        warn(" unencrypted -- you can rebuild with obfuscation later once")
        warn(" PyArmor is fixed.")
        warn("=========================================================")
        MODE = "plain"
        os.environ["SET_BUILD_MODE"] = "plain"
        return True

    # ── Try 3 different subcommand syntaxes ─────────────────────────────────
    attempts = [
        invoker + ["gen", "-O", str(out_dir), "-r", *targets],
        invoker + ["gen", "--output", str(out_dir), "--recursive", *targets],
        invoker + ["obfuscate", "-O", str(out_dir), "-r", *targets],
    ]

    success = False
    for i, cmd in enumerate(attempts, 1):
        info(f"trying PyArmor syntax #{i} ...")
        if out_dir.exists():
            try:
                shutil.rmtree(out_dir)
                out_dir.mkdir(exist_ok=True)
            except Exception:
                pass
        rc, _ = run(cmd)
        if rc == 0:
            info(f"PyArmor syntax #{i} succeeded  [ok]")
            success = True
            break
        warn(f"syntax #{i} failed -- trying next")

    if not success:
        warn("=========================================================")
        warn(" PyArmor ran but every subcommand variant failed.  Possible")
        warn(" causes:")
        warn("   * free-trial quota exceeded -> https://pyarmor.dashingsoft.com/")
        warn("   * anti-virus quarantined the runtime (check Windows Defender)")
        warn("   * project files locked by another process")
        warn(" AUTO-FALLBACK: continuing in PLAIN (unprotected) mode.")
        warn("=========================================================")
        MODE = "plain"
        os.environ["SET_BUILD_MODE"] = "plain"
        return True

    # ── Flatten if PyArmor nested the output one level deeper ───────────────
    if not (out_dir / "desktop_app.py").exists():
        nested = list(out_dir.glob("**/desktop_app.py"))
        if nested:
            actual_root = nested[0].parent
            warn(f"output nested in {actual_root.relative_to(out_dir)} -- flattening")
            for item in actual_root.iterdir():
                shutil.move(str(item), str(out_dir / item.name))
        else:
            warn("PyArmor ran but desktop_app.py is missing from dist_obf/")
            warn("AUTO-FALLBACK: continuing in PLAIN mode.")
            MODE = "plain"
            os.environ["SET_BUILD_MODE"] = "plain"
            return True

    info("source obfuscation complete  [ok]")
    return True


# ---------------------------------------------------------------------------
# Phase 5 -- Copy data assets (only needed in protected mode)
# ---------------------------------------------------------------------------
def copy_assets() -> bool:
    if MODE == "plain":
        banner("STEP 5  -  Copy assets  [skipped: plain mode uses source tree directly]")
        return True

    banner("STEP 5  -  Copy data assets next to obfuscated source")
    out_dir = ROOT / "dist_obf"

    def _tree(name):
        src = ROOT / name
        if not src.exists():
            info(f"skip  {name}/  -- not present")
            return
        dst = out_dir / name
        if dst.exists():
            shutil.rmtree(dst)
        try:
            shutil.copytree(src, dst)
            info(f"copied  {name}/")
        except Exception as e:
            warn(f"could not copy {name}/: {e}")

    def _file(name):
        src = ROOT / name
        if not src.exists():
            info(f"skip  {name}  -- not present")
            return
        try:
            shutil.copy2(src, out_dir / src.name)
            info(f"copied  {name}")
        except Exception as e:
            warn(f"could not copy {name}: {e}")

    for d in ("templates", "static", "rules", "keys"):
        _tree(d)
    for f in (".env", "Secure_Eye_Trust.spec", "app.manifest",
              "app_icon.ico", "app_icon.png", "requirements_build.txt"):
        _file(f)

    if not (out_dir / "Secure_Eye_Trust.spec").exists():
        err("spec file missing from dist_obf/ after copy -- abort.")
        return False
    info("assets copied  [ok]")
    return True


# ---------------------------------------------------------------------------
# Phase 6 -- PyInstaller
# ---------------------------------------------------------------------------
def package() -> bool:
    banner("STEP 6  -  Run PyInstaller")

    if MODE == "plain":
        work_dir = ROOT
    else:
        work_dir = ROOT / "dist_obf"

    rc, _ = run([sys.executable, "-m", "PyInstaller",
                 "--noconfirm", "--clean", "Secure_Eye_Trust.spec"],
                cwd=work_dir)
    if rc != 0:
        warn("PyInstaller failed with --clean -- trying without it ...")
        rc, _ = run([sys.executable, "-m", "PyInstaller",
                     "--noconfirm", "Secure_Eye_Trust.spec"],
                    cwd=work_dir)
    if rc != 0:
        err("PyInstaller failed.  Most common cause: a missing hidden import.")
        warn_file = work_dir / "build" / "Secure_Eye_Trust" / "warn-Secure_Eye_Trust.txt"
        err(f"  -> open  {warn_file}  for the list of missing modules,")
        err("     then add them to the 'hiddenimports' list in")
        err("     Secure_Eye_Trust.spec and re-run this script.")
        return False

    src_exe = work_dir / "dist" / "Secure_Eye_Trust.exe"
    if not src_exe.exists():
        cand = work_dir / "dist" / "Secure_Eye_Trust" / "Secure_Eye_Trust.exe"
        if cand.exists():
            src_exe = cand
    if not src_exe.exists():
        err("Build succeeded but Secure_Eye_Trust.exe was not found.")
        err(f"  -> look inside  {work_dir / 'dist'}  manually.")
        return False

    final_dir = ROOT / "dist"
    final_dir.mkdir(exist_ok=True)
    final_exe = final_dir / "Secure_Eye_Trust.exe"
    try:
        shutil.copy2(src_exe, final_exe)
        size_mb = final_exe.stat().st_size / 1e6
        info(f"final .exe  ->  {final_exe}   ({size_mb:.1f} MB)")
        return True
    except Exception as e:
        err(f"could not copy .exe to ./dist: {e}")
        return False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    try:
        LOG_FILE.write_text(
            f"Secure Eye Trust+ build  -  {datetime.now()}\n"
            f"project root : {ROOT}\n"
            f"python       : {sys.executable}\n"
            f"version      : {sys.version}\n"
            f"build mode   : {MODE}\n\n",
            encoding="utf-8",
        )
    except Exception:
        pass

    print("")
    log("=" * 64)
    log("  Secure Eye Trust+  Python build orchestrator")
    log("=" * 64)
    log(f"  project root : {ROOT}")
    log(f"  build mode   : {MODE.upper()}")
    log(f"  log file     : {LOG_FILE}")
    log("=" * 64)
    print("")

    success = False
    try:
        if not preflight():
            err("pre-flight checks failed -- fix issues above and re-run.")
            return 2
        if not install_deps():
            return 3
        clean()
        if not obfuscate():
            return 4
        if not copy_assets():
            return 5
        if not package():
            return 6
        success = True
    except Exception:
        err("UNEXPECTED EXCEPTION -- full traceback follows:")
        tb = traceback.format_exc()
        for ln in tb.splitlines():
            log(ln, "TRACE")
    finally:
        elapsed = time.time() - START_TIME
        print("")
        log("=" * 64)
        if success:
            log("  BUILD COMPLETE  [ok]")
            log(f"  output  : {ROOT / 'dist' / 'Secure_Eye_Trust.exe'}")
        else:
            log("  BUILD FAILED  [error]")
        log(f"  elapsed : {elapsed:.0f}s   errors: {len(ERR_LOG)}   warnings: {len(WARN_LOG)}")
        log(f"  log file: {LOG_FILE}")
        if ERR_LOG:
            log("")
            log("  Errors recap (newest first):")
            for e in ERR_LOG[-10:][::-1]:
                log(f"    * {e}")
        log("=" * 64)

    return 0 if success else 1


if __name__ == "__main__":
    rc = 1
    try:
        rc = main() or 0
    except SystemExit as e:
        rc = int(e.code) if isinstance(e.code, int) else 1
    except KeyboardInterrupt:
        log("interrupted by user (Ctrl+C)")
        rc = 130
    except Exception:
        try:
            traceback.print_exc()
        except Exception:
            pass
        rc = 1

    # Final pause -- in case the user runs this directly outside the .bat
    print("")
    try:
        input("Press Enter to finish ...")
    except (EOFError, KeyboardInterrupt):
        pass
    sys.exit(rc)
